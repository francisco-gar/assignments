import React from 'react'

function Header() {
    return (
        <div>
            <h3>To Do List</h3>
        </div>
    )
}

export default Header
